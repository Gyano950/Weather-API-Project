function adjustRating(rating) {
    document.getElementById("ratingvalue").innerHTML = rating;
}
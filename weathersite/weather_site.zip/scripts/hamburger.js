function toggleNavMenu() {
    document.getElementById("myNav").classList.toggle("hide");

}